package com.upivoice.alert

import android.content.Context

data class Txn(val time: Long, val app: String, val debit: Boolean, val amount: Double)

/** Saves every announced payment on the phone (no internet, no server). */
object Tracker {
    private const val PREF = "tracker"
    private const val KEY = "log"
    private const val MAX = 5000

    @Synchronized
    fun add(ctx: Context, app: String, debit: Boolean, amount: Double) {
        val p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val lines = (p.getString(KEY, "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()
        lines.add("${System.currentTimeMillis()}|${app.replace("|", " ")}|${if (debit) "D" else "C"}|$amount")
        val keep = if (lines.size > MAX) lines.takeLast(MAX) else lines
        p.edit().putString(KEY, keep.joinToString("\n")).apply()
    }

    @Synchronized
    fun all(ctx: Context): List<Txn> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        return raw.split("\n").mapNotNull { line ->
            val f = line.split("|")
            if (f.size != 4) return@mapNotNull null
            val t = f[0].toLongOrNull() ?: return@mapNotNull null
            val a = f[3].toDoubleOrNull() ?: return@mapNotNull null
            Txn(t, f[1], f[2] == "D", a)
        }
    }

    @Synchronized
    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}

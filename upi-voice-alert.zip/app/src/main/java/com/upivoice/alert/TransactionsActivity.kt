package com.upivoice.alert

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class TransactionsActivity : Activity() {

    private val apps = listOf("All", "PhonePe", "Google Pay", "BHIM", "super.money", "Amazon Pay", "Others")
    private val periods = listOf("Today", "7 days", "Month", "All")
    private var appIdx = 0
    private var periodIdx = 0

    private lateinit var appRow: LinearLayout
    private lateinit var periodRow: LinearLayout
    private lateinit var body: LinearLayout

    private val red = Color.parseColor("#C62828")
    private val green = Color.parseColor("#2E7D32")
    private val grey = Color.parseColor("#757575")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        root.addView(tv("Transactions & analysis", 22f, bold = true))

        appRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(HorizontalScrollView(this).apply { addView(appRow) })

        periodRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(periodRow)

        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(body)

        setContentView(ScrollView(this).apply { addView(root) })
        buildButtons()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::body.isInitialized) refresh()
    }

    private fun buildButtons() {
        appRow.removeAllViews()
        apps.forEachIndexed { i, name ->
            appRow.addView(chip(name, i == appIdx) { appIdx = i; buildButtons(); refresh() })
        }
        periodRow.removeAllViews()
        periods.forEachIndexed { i, name ->
            periodRow.addView(
                chip(name, i == periodIdx) { periodIdx = i; buildButtons(); refresh() },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
    }

    private fun refresh() {
        body.removeAllViews()
        val start = periodStart()
        val filtered = Tracker.all(this).filter { matchesApp(it) }
        val list = filtered.filter { it.time >= start }.sortedByDescending { it.time }

        if (list.isEmpty()) {
            body.addView(tv("No payments here yet. New payments appear automatically.", 16f, color = grey, top = 16))
            return
        }

        val spent = list.filter { it.debit }
        val received = list.filter { !it.debit }

        body.addView(statBlock("SPENT", spent, red))
        body.addView(statBlock("RECEIVED", received, green))
        val net = received.sumOf { it.amount } - spent.sumOf { it.amount }
        body.addView(
            tv("Net: ${if (net >= 0) "+" else "-"}${money(kotlin.math.abs(net))}", 16f, bold = true, top = 8)
        )

        if (appIdx == 0) {
            body.addView(tv("By app", 18f, bold = true, top = 20))
            list.groupBy { it.app }
                .toList()
                .sortedByDescending { (_, v) -> v.filter { it.debit }.sumOf { it.amount } }
                .forEach { (app, v) ->
                    val out = v.filter { it.debit }.sumOf { it.amount }
                    val inn = v.filter { !it.debit }.sumOf { it.amount }
                    body.addView(tv("$app: spent ${money(out)} · received ${money(inn)}", 15f, top = 4))
                }
        }

        body.addView(tv("Spent per day (last 7 days)", 18f, bold = true, top = 20))
        body.addView(bars(filtered.filter { it.debit }))
        body.addView(tv("Received per day (last 7 days)", 18f, bold = true, top = 16))
        body.addView(bars(filtered.filter { !it.debit }))

        body.addView(tv("Transactions (${list.size})", 18f, bold = true, top = 20))
        val fmt = SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH)
        list.take(200).forEach { t ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            left.addView(tv(t.app, 16f, bold = true))
            left.addView(tv(fmt.format(Date(t.time)), 13f, color = grey))
            row.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(
                tv((if (t.debit) "-" else "+") + money(t.amount), 16f, bold = true, color = if (t.debit) red else green)
            )
            body.addView(row)
        }
        if (list.size > 200) body.addView(tv("Showing the latest 200.", 13f, color = grey, top = 8))
    }

    private fun statBlock(label: String, l: List<Txn>, color: Int): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(16), 0, 0)
        }
        box.addView(tv("$label  ${money(l.sumOf { it.amount })}", 22f, bold = true, color = color))
        if (l.isEmpty()) {
            box.addView(tv("0 payments", 14f, color = grey))
        } else {
            val avg = l.sumOf { it.amount } / l.size
            val big = l.maxOf { it.amount }
            box.addView(tv("${l.size} payments · average ${money(avg)} · biggest ${money(big)}", 14f, color = grey))
        }
        return box
    }

    /** Text bar chart for the last 7 days. */
    private fun bars(list: List<Txn>): TextView {
        val fmt = SimpleDateFormat("EEE d", Locale.ENGLISH)
        val days = (6 downTo 0).map { i ->
            val c = todayStart().apply { add(Calendar.DAY_OF_MONTH, -i) }
            val s = c.timeInMillis
            c.add(Calendar.DAY_OF_MONTH, 1)
            val e = c.timeInMillis
            Pair(fmt.format(Date(s)), list.filter { it.time in s until e }.sumOf { it.amount })
        }
        val max = days.maxOf { it.second }
        if (max <= 0.0) return tv("No payments in the last 7 days", 14f, color = grey)

        val sb = StringBuilder()
        days.forEach { (label, sum) ->
            var n = (sum / max * 12).roundToInt()
            if (sum > 0 && n == 0) n = 1
            sb.append(String.format(Locale.US, "%-6s %-12s %s\n", label, "█".repeat(n), if (sum > 0) money(sum) else "-"))
        }
        return tv(sb.toString().trimEnd(), 13f, mono = true)
    }

    private fun matchesApp(t: Txn): Boolean = when (appIdx) {
        0 -> true
        6 -> t.app !in apps.subList(1, 6)
        else -> t.app == apps[appIdx]
    }

    private fun todayStart(): Calendar = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }

    private fun periodStart(): Long {
        val c = todayStart()
        return when (periodIdx) {
            0 -> c.timeInMillis
            1 -> { c.add(Calendar.DAY_OF_MONTH, -6); c.timeInMillis }
            2 -> { c.set(Calendar.DAY_OF_MONTH, 1); c.timeInMillis }
            else -> 0L
        }
    }

    private fun money(v: Double) = "₹" + String.format(Locale.US, "%,.2f", v)

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun chip(label: String, selected: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        alpha = if (selected) 1f else 0.45f
        setOnClickListener { onClick() }
    }

    private fun tv(
        t: String, size: Float, bold: Boolean = false, color: Int? = null,
        mono: Boolean = false, top: Int = 0
    ) = TextView(this).apply {
        text = t
        textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        if (mono) typeface = Typeface.MONOSPACE
        if (color != null) setTextColor(color)
        setPadding(0, dp(top), 0, 0)
    }
}

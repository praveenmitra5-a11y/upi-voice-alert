package com.upivoice.alert

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var status: TextView
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val logoSize = (72 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        // Logo + title
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_foreground)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#0B5D3B"))
            }
        }, LinearLayout.LayoutParams(logoSize, logoSize))
        header.addView(TextView(this).apply {
            text = "UPI Voice Alert"
            textSize = 26f
            setPadding(pad / 2, 0, 0, 0)
        })
        root.addView(header)

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(status)

        root.addView(makeButton("View transactions & analysis") {
            startActivity(Intent(this, TransactionsActivity::class.java))
        })

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        root.addView(Switch(this).apply {
            text = "Also announce money sent (debits)"
            isChecked = prefs.getBoolean("announce_debits", true)
            setPadding(0, pad / 2, 0, pad / 2)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("announce_debits", on).apply() }
        })

        root.addView(TextView(this).apply {
            text = "Setup"
            textSize = 20f
            setPadding(0, pad / 2, 0, 0)
        })
        root.addView(makeButton("1. Allow notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(makeButton("2. Battery: don't restrict this app") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(makeButton("3. Test voice") {
            if (ttsReady) tts?.speak("Payment received. 500 rupees", TextToSpeech.QUEUE_FLUSH, null, "test")
        })
        root.addView(makeButton("Clear history") {
            AlertDialog.Builder(this)
                .setMessage("Delete all saved payment history?")
                .setPositiveButton("Delete") { _, _ -> Tracker.clear(this) }
                .setNegativeButton("Cancel", null)
                .show()
        })

        setContentView(ScrollView(this).apply { addView(root) })

        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) {
                tts?.language = Locale("en", "IN")
                ttsReady = true
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        status.text = if (enabled) "✅ Listening for payments" else "⚠️ Notification access is OFF"
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    private fun makeButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }
}

package com.upivoice.alert

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var summary: TextView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var period = 0 // 0 = today, 1 = this month, 2 = all time

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "UPI Voice Alert"
            textSize = 26f
        })
        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(status)

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        root.addView(Switch(this).apply {
            text = "Also announce money sent (debits)"
            isChecked = prefs.getBoolean("announce_debits", true)
            setPadding(0, pad / 2, 0, pad / 2)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("announce_debits", on).apply() }
        })

        root.addView(makeButton("1. Allow notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(makeButton("2. Battery: don't restrict this app") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(makeButton("3. Test voice") {
            if (ttsReady) tts?.speak("Payment received. 500 rupees", TextToSpeech.QUEUE_FLUSH, null, "test")
        })

        // Summary section
        root.addView(TextView(this).apply {
            text = "Spending summary"
            textSize = 20f
            setPadding(0, pad, 0, pad / 4)
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Today", "This month", "All").forEachIndexed { i, label ->
            row.addView(
                makeButton(label) { period = i; refreshSummary() },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
        root.addView(row)

        summary = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(summary)

        root.addView(makeButton("Clear history") {
            AlertDialog.Builder(this)
                .setMessage("Delete all saved payment history?")
                .setPositiveButton("Delete") { _, _ -> Tracker.clear(this); refreshSummary() }
                .setNegativeButton("Cancel", null)
                .show()
        })

        setContentView(ScrollView(this).apply { addView(root) })

        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) {
                tts?.language = Locale("en", "IN")
                ttsReady = true
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        status.text = if (enabled) "✅ Listening for payments" else "⚠️ Notification access is OFF"
        refreshSummary()
    }

    private fun refreshSummary() {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (period == 1) set(Calendar.DAY_OF_MONTH, 1)
        }
        val start = if (period == 2) 0L else cal.timeInMillis
        val label = listOf("Today", "This month", "All time")[period]
        val list = Tracker.all(this).filter { it.time >= start }

        if (list.isEmpty()) {
            summary.text = "$label: no payments yet"
            return
        }

        val sb = StringBuilder()
        val spent = list.filter { it.debit }
        val received = list.filter { !it.debit }
        sb.append("$label\n")
        sb.append("Spent: ${money(spent.sumOf { it.amount })} (${spent.size} payments)\n")
        sb.append("Received: ${money(received.sumOf { it.amount })} (${received.size} payments)\n")
        sb.append("\nBy app\n")
        list.groupBy { it.app }
            .toList()
            .sortedByDescending { (_, v) -> v.filter { it.debit }.sumOf { it.amount } }
            .forEach { (app, v) ->
                val out = v.filter { it.debit }.sumOf { it.amount }
                val inn = v.filter { !it.debit }.sumOf { it.amount }
                sb.append("$app: spent ${money(out)}, received ${money(inn)}\n")
            }
        summary.text = sb.toString()
    }

    private fun money(v: Double) = "₹" + String.format(Locale.US, "%,.2f", v)

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    private fun makeButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }
}

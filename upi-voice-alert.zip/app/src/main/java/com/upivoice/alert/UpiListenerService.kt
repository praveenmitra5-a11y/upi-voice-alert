package com.upivoice.alert

import android.app.Notification
import android.media.AudioAttributes
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale

class UpiListenerService : NotificationListenerService() {

    private var tts: TextToSpeech? = null
    private var ready = false
    private var lastKey = ""
    private var lastTime = 0L

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("en", "IN")
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                ready = true
            }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        val isSms = pkg in SMS_APPS
        val appName = UPI_APPS[pkg] ?: (if (isSms) "Bank SMS" else return)

        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val body = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        val text = "$title $body"
        val lower = text.lowercase()

        if (isSms && "upi" !in lower) return          // bank SMS must mention UPI
        if (BLOCK_WORDS.any { it in lower }) return    // ignore requests / failures / pending

        // Debit is checked first: a debit SMS can also contain the word "credited" (to the receiver)
        val isDebit = DEBIT_REGEX.containsMatchIn(lower)
        val isCredit = !isDebit && CREDIT_WORDS.any { it in lower }
        if (!isDebit && !isCredit) return

        val amount = AMOUNT_REGEX.find(text)?.groupValues?.get(1)?.replace(",", "") ?: return
        val amountValue = amount.toDoubleOrNull() ?: return

        // Same payment can arrive as app notification + bank SMS. Handle it once.
        val now = System.currentTimeMillis()
        val key = (if (isDebit) "D" else "C") + amount
        if (key == lastKey && now - lastTime < 30_000) return
        lastKey = key
        lastTime = now

        // Always save for the summary, even if voice for debits is switched off
        Tracker.add(this, appName, isDebit, amountValue)

        val announceDebits = getSharedPreferences("settings", MODE_PRIVATE)
            .getBoolean("announce_debits", true)
        if (isDebit && !announceDebits) return

        val prefix = if (isDebit) "Payment sent." else "Payment received."
        speak("$prefix ${amountToWords(amount)}")
    }

    private fun amountToWords(amount: String): String {
        val parts = amount.split(".")
        val rupees = parts[0]
        val paise = parts.getOrNull(1)?.padEnd(2, '0')?.take(2)?.toIntOrNull() ?: 0
        return if (paise > 0) "$rupees rupees $paise paise" else "$rupees rupees"
    }

    private fun speak(message: String) {
        if (!ready) return
        tts?.speak(message, TextToSpeech.QUEUE_ADD, null, "upi-alert")
    }

    companion object {
        // Package name -> name shown in the summary
        val UPI_APPS = mapOf(
            "com.google.android.apps.nbu.paisa.user" to "Google Pay",
            "com.phonepe.app" to "PhonePe",
            "net.one97.paytm" to "Paytm",
            "in.org.npci.upiapp" to "BHIM",
            "money.super.payments" to "super.money",
            "in.amazon.mShop.android.shopping" to "Amazon Pay",
            "com.dreamplug.androidapp" to "CRED",
            "com.mobikwik_new" to "MobiKwik",
            "com.freecharge.android" to "Freecharge",
            "com.sbi.upi" to "SBI Pay",
            "com.csam.icici.bank.imobile" to "ICICI iMobile",
            "com.snapwork.hdfc" to "HDFC Bank",
            "com.axis.mobile" to "Axis Mobile"
        )

        // Bank SMS ("Rs 500 credited ... UPI") works for every UPI app
        val SMS_APPS = setOf(
            "com.google.android.apps.messaging",
            "com.samsung.android.messaging",
            "com.android.mms"
        )

        val CREDIT_WORDS = listOf("received", "credited", "paid you", "sent you", "deposited")
        val BLOCK_WORDS = listOf("request", "failed", "declined", "pending")

        // Money going OUT: "debited", "Paid Rs 200 to", "sent to". "paid you" / "sent you" are credits.
        val DEBIT_REGEX = Regex("""debited|\b(?:paid|sent)\s+(?!you\b)""")

        val AMOUNT_REGEX = Regex("""(?:₹|rs\.?|inr)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)
    }
}

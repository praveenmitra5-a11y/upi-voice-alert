package com.upivoice.alert

import android.app.Notification
import android.media.AudioAttributes
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale

class UpiListenerService : NotificationListenerService() {

    private var tts: TextToSpeech? = null
    private var ready = false
    private var lastAmount = ""
    private var lastTime = 0L

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("en", "IN")
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                ready = true
            }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        val isSms = pkg in SMS_APPS
        if (pkg !in UPI_APPS && !isSms) return

        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val body = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        val text = "$title $body"
        val lower = text.lowercase()

        if (isSms && "upi" !in lower) return          // bank SMS must mention UPI
        if (BLOCK_WORDS.any { it in lower }) return    // ignore debits / requests / failures
        if (CREDIT_WORDS.none { it in lower }) return  // only money coming IN

        val amount = AMOUNT_REGEX.find(text)?.groupValues?.get(1)?.replace(",", "") ?: return

        // Same payment can arrive as app notification + bank SMS. Say it once.
        val now = System.currentTimeMillis()
        if (amount == lastAmount && now - lastTime < 30_000) return
        lastAmount = amount
        lastTime = now

        speak("Payment received. ${amountToWords(amount)}")
    }

    private fun amountToWords(amount: String): String {
        val parts = amount.split(".")
        val rupees = parts[0]
        val paise = parts.getOrNull(1)?.padEnd(2, '0')?.take(2)?.toIntOrNull() ?: 0
        return if (paise > 0) "$rupees rupees $paise paise" else "$rupees rupees"
    }

    private fun speak(message: String) {
        if (!ready) return
        tts?.speak(message, TextToSpeech.QUEUE_ADD, null, "upi-alert")
    }

    companion object {
        // All the money apps whose notifications are read
        val UPI_APPS = setOf(
            "com.google.android.apps.nbu.paisa.user", // Google Pay
            "com.phonepe.app",                        // PhonePe
            "net.one97.paytm",                        // Paytm
            "in.org.npci.upiapp",                     // BHIM
            "in.amazon.mShop.android.shopping",       // Amazon Pay
            "com.dreamplug.androidapp",               // CRED
            "com.mobikwik_new",                       // MobiKwik
            "com.freecharge.android",                 // Freecharge
            "com.sbi.upi",                            // SBI Pay
            "com.csam.icici.bank.imobile",            // ICICI iMobile
            "com.snapwork.hdfc",                      // HDFC Bank
            "com.axis.mobile"                         // Axis Mobile
        )

        // Bank SMS ("Rs 500 credited ... UPI") works for every UPI app
        val SMS_APPS = setOf(
            "com.google.android.apps.messaging",
            "com.samsung.android.messaging",
            "com.android.mms"
        )

        val CREDIT_WORDS = listOf("received", "credited", "paid you", "sent you", "deposited")
        val BLOCK_WORDS = listOf("debited", "paid to", "sent to", "request", "failed", "declined", "pending")

        val AMOUNT_REGEX = Regex("""(?:₹|rs\.?|inr)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)
    }
}

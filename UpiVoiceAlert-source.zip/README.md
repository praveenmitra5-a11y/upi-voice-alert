# UPI Voice Alert

Android app that speaks payment amounts aloud (like a soundbox) by reading
notifications from UPI apps: PhonePe, Google Pay, BHIM, super.money, Amazon Pay, Paytm.
It does NOT read SMS. It keeps a per-app transaction list plus spent / received totals.

## First-time setup on the phone
1. Open the app -> Enable notification access -> turn on UPI Voice Alert.
   Android 13+: if the switch is greyed out, tap "Open App info", three-dot menu
   -> "Allow restricted settings", then try again.
2. Tap "Allow background running" and set the app to Unrestricted / Don't optimise
   (Xiaomi, Oppo, Vivo, Realme, Samsung: also allow Autostart).
3. Tap "Test voice". Keep media volume up.

## Customising
- Add/remove apps: AppConfig.kt
- Sent/received keywords: PaymentParser.kt
- Spoken sentence: Speech.kt

package com.upivoicealert

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class PaymentListenerService : NotificationListenerService() {

    private lateinit var announcer: Announcer
    private val recent = HashMap<String, Long>()

    override fun onCreate() {
        super.onCreate()
        announcer = Announcer(this)
    }

    override fun onDestroy() {
        announcer.shutdown()
        super.onDestroy()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        requestRebind(ComponentName(this, PaymentListenerService::class.java))
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName ?: return
        if (AppConfig.nameFor(pkg) == null) return // only known payment apps

        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()

        val txn = PaymentParser.parse(pkg, title, text) ?: return

        // Ignore the same notification being re-posted/updated within a few seconds.
        val sig = "${sbn.key}|${txn.type}|${txn.amount}|${text.hashCode()}"
        val now = System.currentTimeMillis()
        synchronized(recent) {
            recent.entries.removeAll { now - it.value > 10_000 }
            if (recent.containsKey(sig)) return
            recent[sig] = now
        }

        TxnDb.get(this).insert(txn)
        val hindi = Prefs.hindi(this)
        announcer.speak(Speech.build(txn, hindi), hindi)
    }
}

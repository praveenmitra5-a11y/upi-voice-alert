package com.upivoicealert

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Small wrapper around Android Text-to-Speech. */
class Announcer(context: Context) {

    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = ArrayList<Pair<String, Boolean>>()
    private var counter = 0

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                synchronized(this) {
                    ready = true
                    pending.forEach { say(it.first, it.second) }
                    pending.clear()
                }
            }
        }
    }

    @Synchronized
    fun speak(text: String, hindi: Boolean) {
        if (!ready) {
            pending.add(text to hindi)
            return
        }
        say(text, hindi)
    }

    private fun say(text: String, hindi: Boolean) {
        val t = tts ?: return
        val locale = if (hindi) Locale("hi", "IN") else Locale("en", "IN")
        val r = t.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale.getDefault())
        }
        t.speak(text, TextToSpeech.QUEUE_ADD, null, "upi-${counter++}")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

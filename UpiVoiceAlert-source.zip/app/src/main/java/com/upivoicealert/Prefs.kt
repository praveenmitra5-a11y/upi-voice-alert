package com.upivoicealert

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("upi_alert", Context.MODE_PRIVATE)

    fun hindi(c: Context): Boolean = sp(c).getBoolean("hindi", false)

    fun setHindi(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("hindi", v).apply()
    }
}

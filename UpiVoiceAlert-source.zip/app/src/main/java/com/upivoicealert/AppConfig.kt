package com.upivoicealert

/**
 * Only notifications from these apps are read. To support another app,
 * add its package name here (and its display name to [names]).
 */
object AppConfig {
    private val packages = mapOf(
        "com.phonepe.app" to "PhonePe",
        "com.google.android.apps.nbu.paisa.user" to "Google Pay",
        "com.google.android.apps.nbu.paisa.merchant" to "Google Pay",
        "in.org.npci.upiapp" to "BHIM",
        "money.super.payments" to "super.money",
        "in.amazon.mShop.android.shopping" to "Amazon Pay",
        "com.amazon.mShop.android.shopping" to "Amazon Pay",
        "net.one97.paytm" to "Paytm"
    )

    val names = listOf("PhonePe", "Google Pay", "BHIM", "super.money", "Amazon Pay", "Paytm")

    fun nameFor(pkg: String): String? = packages[pkg]
}

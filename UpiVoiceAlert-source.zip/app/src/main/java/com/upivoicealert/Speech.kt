package com.upivoicealert

/** Builds the sentence that gets spoken. */
object Speech {
    fun build(t: Txn, hindi: Boolean): String {
        val total = Math.round(t.amount * 100)
        val r = total / 100
        val p = total % 100
        val party = t.party
        val received = t.type == "RECEIVED"

        if (hindi) {
            val amt = if (p == 0L) "$r रुपये" else "$r रुपये $p पैसे"
            var s = if (received) "${t.app} पर $amt प्राप्त हुए" else "${t.app} से $amt भेजे गए"
            if (party != null) s += if (received) ", $party से" else ", $party को"
            return s
        }

        val amt = if (p == 0L) "$r rupees" else "$r rupees and $p paise"
        var s = if (received) "${t.app}. Received $amt" else "${t.app}. Paid $amt"
        if (party != null) s += if (received) " from $party" else " to $party"
        return s
    }
}

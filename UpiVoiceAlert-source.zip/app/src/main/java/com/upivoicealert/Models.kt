package com.upivoicealert

data class Txn(
    val id: Long = 0,
    val app: String,
    val amount: Double,
    val type: String, // "SENT" or "RECEIVED"
    val party: String?,
    val time: Long
)

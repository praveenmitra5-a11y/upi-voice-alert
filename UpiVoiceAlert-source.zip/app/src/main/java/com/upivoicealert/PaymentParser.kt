package com.upivoicealert

import java.util.Locale

/** Turns a payment-app notification into a [Txn], or null if it is not a completed payment. */
object PaymentParser {

    private val amountRe = Regex(
        """(?:₹|\b(?:rs\.?|inr))\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)""",
        RegexOption.IGNORE_CASE
    )

    // Notifications containing any of these are skipped.
    private val ignoreWords = listOf(
        "request", "reminder", "failed", "declined", "pending",
        "otp", "expire", "offer", "coupon"
    )

    private val creditWords = listOf(
        "received", "credited", "paid you", "sent you", "deposited", "refund"
    )

    private val debitWords = listOf(
        "paid", "sent", "debited", "successful", "transferred", "payment of"
    )

    private val payerRe = Regex(
        """^(.{2,40}?)\s+(?:has\s+)?(?:paid|sent)\s+you""",
        RegexOption.IGNORE_CASE
    )
    private val fromRe = Regex(
        """\bfrom\s+([^.,!\n]{2,40}?)(?=\s+(?:on|via|using|in|at|has|is|to|for)\b|[.,!\n]|$)""",
        RegexOption.IGNORE_CASE
    )
    private val toRe = Regex(
        """\bto\s+([^.,!\n]{2,40}?)(?=\s+(?:on|via|using|from|in|at|has|is|for)\b|[.,!\n]|$)""",
        RegexOption.IGNORE_CASE
    )

    fun parse(pkg: String, title: String, text: String): Txn? {
        val app = AppConfig.nameFor(pkg) ?: return null
        val full = "$title $text"
        val low = full.lowercase(Locale.ROOT)

        if (ignoreWords.any { low.contains(it) }) return null

        val amount = amountRe.find(full)
            ?.groupValues?.get(1)
            ?.replace(",", "")
            ?.toDoubleOrNull() ?: return null
        if (amount <= 0.0) return null

        val type = when {
            creditWords.any { low.contains(it) } -> "RECEIVED"
            debitWords.any { low.contains(it) } -> "SENT"
            else -> return null
        }

        val body = text.ifBlank { title }
        val party = findParty(type, body) ?: findParty(type, title)

        return Txn(
            app = app,
            amount = amount,
            type = type,
            party = party,
            time = System.currentTimeMillis()
        )
    }

    private fun findParty(type: String, s: String): String? {
        if (s.isBlank()) return null
        val m = if (type == "RECEIVED") (payerRe.find(s) ?: fromRe.find(s)) else toRe.find(s)
        return m?.groupValues?.get(1)
            ?.trim()
            ?.trimEnd('.', ',', ' ')
            ?.takeIf {
                it.isNotEmpty() &&
                    !it.contains('@') &&
                    !it.startsWith("your", true) &&
                    it.count { c -> c.isDigit() } <= 4
            }
    }
}

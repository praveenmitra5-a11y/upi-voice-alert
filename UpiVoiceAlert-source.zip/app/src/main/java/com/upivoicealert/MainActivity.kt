package com.upivoicealert

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var db: TxnDb
    private lateinit var announcer: Announcer
    private lateinit var statusText: TextView
    private lateinit var summaryText: TextView
    private lateinit var spinner: Spinner
    private lateinit var adapter: ArrayAdapter<String>

    private val filters = listOf("All apps") + AppConfig.names

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = TxnDb.get(this)
        announcer = Announcer(this)

        val listView = findViewById<ListView>(R.id.list)
        val header = layoutInflater.inflate(R.layout.header_main, listView, false)
        listView.addHeaderView(header, null, false)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        listView.adapter = adapter

        statusText = header.findViewById(R.id.statusText)
        summaryText = header.findViewById(R.id.summaryText)
        spinner = header.findViewById(R.id.appSpinner)

        header.findViewById<Button>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        header.findViewById<Button>(R.id.btnAppInfo).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
        header.findViewById<Button>(R.id.btnBattery).setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        header.findViewById<Button>(R.id.btnTest).setOnClickListener {
            val demo = Txn(
                app = "PhonePe",
                amount = 250.0,
                type = "RECEIVED",
                party = "Ravi",
                time = System.currentTimeMillis()
            )
            val hindi = Prefs.hindi(this)
            announcer.speak(Speech.build(demo, hindi), hindi)
        }

        val sw = header.findViewById<SwitchCompat>(R.id.switchHindi)
        sw.isChecked = Prefs.hindi(this)
        sw.setOnCheckedChangeListener { _, checked -> Prefs.setHindi(this, checked) }

        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, filters)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                refresh()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    override fun onResume() {
        super.onResume()
        TxnDb.onChange = { runOnUiThread { refresh() } }
        refresh()
    }

    override fun onPause() {
        TxnDb.onChange = null
        super.onPause()
    }

    override fun onDestroy() {
        announcer.shutdown()
        super.onDestroy()
    }

    private fun money(v: Double): String = String.format(Locale.US, "₹%,.2f", v)

    private fun refresh() {
        val enabled = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        statusText.text = getString(if (enabled) R.string.status_on else R.string.status_off)

        val sel = spinner.selectedItemPosition
        val app: String? = if (sel <= 0) null else filters[sel]

        val totals = db.totals().filter { app == null || it.app == app }
        val recv = totals.filter { it.type == "RECEIVED" }
        val sent = totals.filter { it.type == "SENT" }

        val sb = StringBuilder()
        sb.append("Received: ").append(money(recv.sumOf { it.sum }))
            .append("  (").append(recv.sumOf { it.count }).append(")\n")
        sb.append("Spent: ").append(money(sent.sumOf { it.sum }))
            .append("  (").append(sent.sumOf { it.count }).append(")")

        if (app == null) {
            totals.groupBy { it.app }.forEach { (name, rows) ->
                val r = rows.filter { it.type == "RECEIVED" }.sumOf { it.sum }
                val s = rows.filter { it.type == "SENT" }.sumOf { it.sum }
                sb.append("\n").append(name)
                    .append(": in ").append(money(r))
                    .append(" · out ").append(money(s))
            }
        }
        summaryText.text = sb.toString()

        adapter.clear()
        adapter.addAll(db.list(app).map { rowText(it) })
        adapter.notifyDataSetChanged()
    }

    private fun rowText(t: Txn): String {
        val received = t.type == "RECEIVED"
        val sign = if (received) "+" else "-"
        val who = t.party?.let { (if (received) "from " else "to ") + it } ?: ""
        val whenStr = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(t.time))
        return "$sign${money(t.amount)}  ${t.type.lowercase()}\n${t.app}  $who  ·  $whenStr"
    }
}

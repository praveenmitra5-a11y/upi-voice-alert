package com.upivoicealert

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class TxnDb private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx.applicationContext, "txns.db", null, 1) {

    data class Total(val app: String, val type: String, val sum: Double, val count: Int)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE txns (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "app TEXT NOT NULL, " +
                "amount REAL NOT NULL, " +
                "type TEXT NOT NULL, " +
                "party TEXT, " +
                "time INTEGER NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insert(t: Txn) {
        val cv = ContentValues().apply {
            put("app", t.app)
            put("amount", t.amount)
            put("type", t.type)
            put("party", t.party)
            put("time", t.time)
        }
        writableDatabase.insert("txns", null, cv)
        onChange?.invoke()
    }

    fun list(app: String?, limit: Int = 300): List<Txn> {
        val out = ArrayList<Txn>()
        val cols = "SELECT id, app, amount, type, party, time FROM txns"
        val c = if (app == null) {
            readableDatabase.rawQuery("$cols ORDER BY time DESC LIMIT $limit", null)
        } else {
            readableDatabase.rawQuery("$cols WHERE app = ? ORDER BY time DESC LIMIT $limit", arrayOf(app))
        }
        c.use {
            while (it.moveToNext()) {
                out.add(
                    Txn(
                        id = it.getLong(0),
                        app = it.getString(1),
                        amount = it.getDouble(2),
                        type = it.getString(3),
                        party = it.getString(4),
                        time = it.getLong(5)
                    )
                )
            }
        }
        return out
    }

    fun totals(): List<Total> {
        val out = ArrayList<Total>()
        val c = readableDatabase.rawQuery(
            "SELECT app, type, SUM(amount), COUNT(*) FROM txns GROUP BY app, type", null
        )
        c.use {
            while (it.moveToNext()) {
                out.add(Total(it.getString(0), it.getString(1), it.getDouble(2), it.getInt(3)))
            }
        }
        return out
    }

    companion object {
        @Volatile
        private var inst: TxnDb? = null

        /** Set by the UI so the list refreshes live when a payment arrives. */
        @Volatile
        var onChange: (() -> Unit)? = null

        fun get(ctx: Context): TxnDb =
            inst ?: synchronized(this) {
                inst ?: TxnDb(ctx).also { inst = it }
            }
    }
}
